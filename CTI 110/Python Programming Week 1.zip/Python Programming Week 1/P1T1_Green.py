# CTI 110
# P1T1
# Green

# say hello
print ("Hello world")

print ("Goodbye!")
